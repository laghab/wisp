# Wisp Keyboard: design handoff for implementation

This folder is the complete UI design for **Wisp**, an Android keyboard (IME) plus its companion settings app. Build a native Android app that matches these designs.

## What the files are

`design/*.dc.html` are design mockups, one screen per file. Each is HTML with:
- markup inside `<x-dc>` (inline `style="…"` holds the exact sizes, colors, radii, fonts),
- `{{holes}}`, `<sc-for>` (loops) and `<sc-if>` (conditionals) filled from the `renderVals()` method in the `<script type="text/x-dc">` block at the bottom,
- CSS `@keyframes` in `<helmet><style>` for every animation (timings and easings are the intended motion spec),
- `<dc-import name="Keys">` = embeds `Keys.dc.html` (the shared key grid component).

They are **reference, not code to ship**. They will not render standalone (they need a design-tool runtime). Read them as a precise spec: sizes are in CSS px, so treat **1 px = 1 dp**. Screens are designed at **390 × 844 dp**.

`design/canvas.json` lists all screens and their titles.

## Screens

### Keyboard (IME)
| File | What it is |
|---|---|
| `Keys.dc.html` | **The key grid component + all 11 themes.** `WISP_THEMES` in its script is the theme token table. Key geometry: 4 rows × 48 dp, 10 dp row gap, 6 dp key gap, 8/4/10 dp padding, row 2 inset 18 dp, shift/backspace flex 1.5, space flex 4.6. Long-press hint glyphs top-right of each letter. |
| `Main.dc.html` | Typing state. Toolbar strip (48 dp) shows tool icons when the field is empty, 3 suggestions when typing (middle = best, bold). Mic button always on the right. Logic for suggestions, auto-cap after sentence end, and send is in its script. |
| `Glide.dc.html` | Glide typing: trail drawn over keys (wide 28%-opacity stroke + 4.5 dp bright stroke, round caps), keys on the path light up in accent, candidates in strip. Gesture guide: glide, swipe left from backspace = delete words, slide on space = cursor, long-press = accents. |
| `Voice.dc.html` | On-device voice typing panel (replaces keys, 302 dp tall). Live transcript: confirmed words white, tentative last ~3 words grey. Waveform bars, pulsing mic rings, pause/resume, undo phrase, auto-punctuation toggle, "Polish" → AI rewrite. |
| `Rewrite.dc.html` | Local LLM rewrite panel. Tone chips (Polish, Friendly, Formal, Shorter, Bullets, Translate→Hindi), shimmer while generating, result card, Replace / Insert below / Regenerate. |
| `Clipboard.dc.html` | Clipboard history: filters (All, Pinned, Links, Codes, Images), 2-col grid, OTP codes auto-detected and auto-expiring, history on/off. |
| `Emoji.dc.html` | Emoji / GIFs / Kaomoji / Symbols tabs, search, category bar, ABC + backspace. |

### Companion app
| File | What it is |
|---|---|
| `Onboard.dc.html` | 3-step setup: enable IME → select IME → download voice model. |
| `Home.dc.html` | Status card, test field, quick-toggle chips, tiles to every settings section. |
| `Typing.dc.html` | Glide, corrections, haptics/sound/long-press sliders, text shortcuts. |
| `Models.dc.html` | Whisper tiny/base/small (download, progress, active), LLM choice (Gemma 3 1B / Qwen2.5 1.5B / Off), behaviour toggles, storage meter. |
| `Themes.dc.html` | Live theme picker: preview keyboard you can type on, 11 theme cards, custom photo, fine-tune toggles, glide-trail colour. |
| `Layouts.dc.html` | Languages (English, Hindi, Hinglish), layout (QWERTY/AZERTY/QWERTZ/Dvorak/Colemak/Workman), modes (full, one-handed, floating, split), keyboard height, number row. |
| `ThemeGallery.dc.html` | Presentation board of all 11 themes. |

## Themes (must be full skins, not colour swaps)
Each theme in `WISP_THEMES` defines: board background (can be a gradient/texture), key and modifier-key backgrounds, text colours, accent, corner radius, border, shadow, glow on highlighted keys, font family/weight/size, letter case, letter spacing, optional backdrop blur (Liquid Glass), optional clipped-corner shape (Cyberpunk), an optional decorative band across the top, and the space-bar label.

Themes: Midnight (default), Factory, Cyberpunk, Material You, Liquid Glass, Modern, Y2K Desktop, Retro, Brutalist, Comic, Manga.
- Material You should use Android dynamic color (`dynamicLightColorScheme`) when "Colour from wallpaper" is on.
- Liquid Glass needs real blur (`RenderEffect.createBlurEffect`, API 31+), with a fallback of translucent keys on older devices.
- Fonts used (all Google Fonts, OFL): Inter, Space Grotesk, JetBrains Mono, Orbitron, VT323, Bangers, Zen Maru Gothic, Chakra Petch, Roboto. Bundle them.
- Theme names deliberately avoid other companies' trademarks (e.g. "Y2K Desktop", "Factory"). Keep it that way.

Make themes data-driven (a theme = one JSON/Kotlin object with these tokens) so users can add custom themes later.

## Core product constraints
- **Privacy is the headline:** the keyboard APK has **no `INTERNET` permission**. Everything runs on-device.
  - Speech and LLM models ship via **Play Asset Delivery** (on-demand asset packs), not in-app HTTP downloads.
  - GIF search lives in a **separate optional add-on app**; the keyboard talks to it via an exported ContentProvider/Intent, never the network.
- Clipboard: never store items flagged sensitive (`ClipDescription.EXTRA_IS_SENSITIVE`, password fields); unpinned items auto-clear after 1 h; codes clear sooner.
- Learned words / personal dictionary stay on-device (Room/SQLite).

## Suggested stack (adjust as you see fit)
- Kotlin, min SDK 26, target latest.
- IME: `InputMethodService`; render the keyboard with Jetpack Compose inside the IME window (set up a `ComposeView` with a lifecycle/saved-state owner, or use a custom `View` + Canvas if Compose latency is too high on low-end devices; key-press latency target < 16 ms).
- Companion app: Jetpack Compose, Material 3, shared `:theme` and `:core` modules with the IME.
- Glide typing: record touch path → resample → match against the lexicon with a shape+location decoder (e.g. key-proximity scoring + dynamic time warping, pruned by a trie, ranked with a unigram/bigram LM). Start with an English 50k word list.
- Voice: **whisper.cpp** via JNI/NDK (ggml tiny/base/small, quantised), streaming in ~2–3 s chunks, VAD to segment. Show partial words grey, commit when stable.
- LLM rewrite: **llama.cpp** (GGUF Q4) via JNI or **MediaPipe LLM Inference** for Gemma 3 1B; use GPU/NNAPI where available.
- Settings shared between app and IME via DataStore.

## Build order
1. Keyboard core: key grid, input, shift/symbols, backspace repeat, haptics, Midnight theme.
2. Suggestion strip + autocorrect + lexicon.
3. Theme engine + all 11 themes + companion app Themes screen.
4. Glide typing + gestures (delete swipe, space-bar cursor, long-press popups).
5. Clipboard, emoji/kaomoji/symbols.
6. Voice (whisper.cpp) + Models screen + asset packs.
7. AI rewrite (local LLM).
8. Layouts, languages (Hindi Devanagari, Hinglish transliteration), one-handed/floating/split modes.

## Placeholders in the designs
- Home screen stat "[N] words glided this week" needs a real value.
- Model sizes are approximate.
